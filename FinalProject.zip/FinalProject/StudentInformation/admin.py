from django.contrib import admin
from StudentInformation.models import StudentDetails
from StudentInformation.models import CourseDetails

# Register your models here.

admin.site.register(StudentDetails)
admin.site.register(CourseDetails)