from django.shortcuts import render
from django.http import HttpResponse
from StudentInformation.models import StudentDetails
from StudentInformation.models import CourseDetails
from django.core.paginator import Paginator
from django.contrib.auth.decorators import login_required
from StudentInformation.models import EnrollmentInfo
from django.db.models import Avg
from decimal import *

# Create your views here.

@login_required
def home(request):
    studentdata = StudentDetails.objects.all()
    coursedata = CourseDetails.objects.all()
    enrollinfo = EnrollmentInfo.objects.all()
    secount = EnrollmentInfo.objects.values('studentid').distinct().count()
    sencount = StudentDetails.objects.filter(year = "Senior").count()
    jcount = StudentDetails.objects.filter(year = "Junior").count()
    sopcount = StudentDetails.objects.filter(year = "Sophomore").count()
    fcount = StudentDetails.objects.filter(year = "Freshman").count()
    coucount = CourseDetails.objects.values('id').distinct().count()
    sengpaavg = list(StudentDetails.objects.filter(year = "Senior").aggregate(Avg('gpa')).values())[0]
    jgpaavg = list(StudentDetails.objects.filter(year = "Junior").aggregate(Avg('gpa')).values())[0]
    sopgpaavg = list(StudentDetails.objects.filter(year = "Sophomore").aggregate(Avg('gpa')).values())[0]
    fgpaavg = list(StudentDetails.objects.filter(year = "Freshman").aggregate(Avg('gpa')).values())[0]
    classdata = {'enrolledcount':secount, 'coursecount':coucount,'seniorcount':sencount, 'senioravg':sengpaavg, 'juniorcount':jcount, 'junioravg': jgpaavg,
    'sophopmorecount':sopcount, 'sophomoreavg':sopgpaavg, 'freshmancount':fcount, 'freshmanavg':fgpaavg}
    context = {'sdata' : studentdata, 'cdata': coursedata, 'edata': enrollinfo, 'classdatas':classdata}
    print(context)
    return render(request, 'StudentInformation/home.html', context)

@login_required
def studentdetails(request):
    studentdata = StudentDetails.objects.all()
    paginator = Paginator(studentdata, 10)
    page = request.GET.get('page')
    minidata = paginator.get_page(page)
    context = {'sdata': minidata}
    return render(request, 'StudentInformation/StudentDetails.html', context)

@login_required
def coursedetails(request):
    coursedata = CourseDetails.objects.all()
    paginator = Paginator(coursedata, 10)
    page = request.GET.get('page')
    minidata = paginator.get_page(page)
    context = {'cdata': minidata}
    return render(request, 'StudentInformation/CourseDetails.html', context)

@login_required
def enrollment(request):
    studentdata = StudentDetails.objects.all()
    coursedata = CourseDetails.objects.all()
    enrollinfo = EnrollmentInfo.objects.all()
    context = {'sdata' : studentdata, 'cdata': coursedata, 'edata': enrollinfo}
    return render(request, 'StudentInformation/enrollment.html', context)

def saveenroll(request):
    if('sid' and 'cid' in request.GET):
        studid = request.GET.get('sid')
        courid = request.GET.get('cid')
        dataobj = EnrollmentInfo(studentid = studid, courseid = courid)
        enrollinfo = EnrollmentInfo.objects.all()
        context = {'edata': enrollinfo}
        enrollcount = EnrollmentInfo.objects.filter(studentid = int(studid)).count()
        print(enrollcount)
        coursecount = EnrollmentInfo.objects.filter(studentid = int(studid), courseid = int(courid)).count()
        if (enrollcount < 3):
            if(coursecount < 1):
                dataobj.save()
                print("Success")
                return HttpResponse("Success")
    print("Fail")
    return HttpResponse("Fail")
    
